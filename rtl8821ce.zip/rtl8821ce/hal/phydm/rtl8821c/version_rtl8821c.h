/*RTL8821C PHY Parameters*/
/* 
[Caution] 
  Since 01/Aug/2015, the commit rules will be simplified. You do not need to fill up the version.h anymore, 
  only the maintenance supervisor fills it before formal release.
*/
#define	RELEASE_DATE_8821C		20170206
#define	COMMIT_BY_8821C			"Coiln"
#define	RELEASE_VERSION_8821C	36
